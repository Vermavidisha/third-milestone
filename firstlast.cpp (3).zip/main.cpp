/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int n,i;
    cout<<"Enter the number";
    cin>>n;
    i=n%10;
    cout<<"Last number is:"<<endl<<i;
    while(n>10)
    {
        n=n/10;
        
    }
    
cout<<"First nnumber is:"<<endl<<n;
    return 0;
}
