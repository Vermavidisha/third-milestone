/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
int n,p=1,rem;                                                               
cout<<"Enter the number";
cin>>n;
for(p=1;n>0;n=n/10)
{
    rem=n%10;
p=p*rem;
}
cout<<"Product of number:"<<endl<<p;
return 0;
}