/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
int n1,n2,maxvalue;
cout<<"Enter the first number";
cin>>n1;
cout<<"Enter the second number";
cin>>n2;
maxvalue=(n1>n2)?n1:n2;
while(1)
{
    if(maxvalue%n1==0&&maxvalue%n2==0){
        cout<<"LCM of"<<n1<<"and"<<n2<<"="<<maxvalue<<endl;
        break;
    }
    ++maxvalue;
}
    return 0;
}
