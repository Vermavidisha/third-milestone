/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
int main()
{
    int n,i=1,fac=1;
    cout<<"Enter the number";
    cin>>n;
   for(i=1;i<=n;i++)
{
  fac= fac*i; 
}
cout<<"Factorial:"<<endl<<fac;
    return 0;
}
