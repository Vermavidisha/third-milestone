/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int i,j,n,count=0,sum=0;
    cout<<"Enter the number";
    cin>>n;
    for(i=1;i<=n;i++)
    {
        count=0;
        for(j=2;j<i/2;j++)
        {
            if(i%j==0)
            {
                count=1;
                break;
            }
        }
        if(count!=1)
        {
            sum=sum+i;
        }
    }
cout<<"Sum of prme number:"<<endl<<sum;
    return 0;
}
