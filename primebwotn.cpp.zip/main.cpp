/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int n,i,j,count=0;
    cout<<"Enter the number";
    cin>>n;
    for(i=1;i<=n;i++)
    {
        count=0;
        for(j=2;j<i/2;j++)
        {
            if(i%j==0)
            {
                count=1;
                break;
            }
        }
        if(count!=1)
        {
            cout<<"Prime number are:"<<endl<<i;
        }
    }

    return 0;
}
